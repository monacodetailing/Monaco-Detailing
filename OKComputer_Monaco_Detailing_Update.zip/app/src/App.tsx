import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useBookingContext } from '@/context/BookingContext';
import { HeroSection } from '@/components/home/HeroSection';
import { BookingModal } from '@/components/booking/BookingModal';
import { LoginForm } from '@/components/admin/LoginForm';
import { Sidebar } from '@/components/admin/Sidebar';
import { Dashboard } from '@/components/admin/Dashboard';
import { BookingDetail } from '@/components/admin/BookingDetail';
import { NewBooking } from '@/components/admin/NewBooking';
import { CalendarView } from '@/components/admin/CalendarView';
import { Settings } from '@/components/admin/Settings';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

function App() {
  const [view, setView] = useState<'home' | 'admin'>('home');
  const [adminView, setAdminView] = useState<'dashboard' | 'new-booking' | 'calendar' | 'settings'>('dashboard');
  const [selectedBookingId, setSelectedBookingId] = useState<string | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const { isAuthenticated, login, logout, username } = useAuth();
  const { 
    bookings, 
    addBooking, 
    updateBookingStatus, 
    getUpcomingBookings, 
    getStats, 
    getBookingById,
    refreshBookings 
  } = useBookingContext();

  const stats = getStats();
  const upcomingBookings = getUpcomingBookings();

  // Refresh bookings when entering admin view
  useEffect(() => {
    if (view === 'admin' && isAuthenticated) {
      refreshBookings();
    }
  }, [view, isAuthenticated, refreshBookings]);

  const handleAdminClick = () => {
    setView('admin');
  };

  const handleLogin = (user: string, password: string) => {
    const success = login(user, password);
    if (success) {
      setAdminView('dashboard');
    }
    return success;
  };

  const handleLogout = () => {
    logout();
    setView('home');
    setAdminView('dashboard');
  };

  const handleViewBooking = (bookingId: string) => {
    setSelectedBookingId(bookingId);
  };

  const handleBackToDashboard = () => {
    setSelectedBookingId(null);
  };

  const handleUpdateBookingStatus = (bookingId: string, status: Parameters<typeof updateBookingStatus>[1]) => {
    updateBookingStatus(bookingId, status);
  };

  const handleSaveNewBooking = (bookingData: any) => {
    addBooking(bookingData);
    toast.success('Turno creado correctamente');
    setAdminView('dashboard');
  };

  // Render Home View
  if (view === 'home') {
    return (
      <>
        <HeroSection
          onReserve={() => setIsBookingModalOpen(true)}
          onAdminClick={handleAdminClick}
        />
        <BookingModal
          isOpen={isBookingModalOpen}
          onClose={() => setIsBookingModalOpen(false)}
        />
        <Toaster />
      </>
    );
  }

  // Render Admin Login
  if (view === 'admin' && !isAuthenticated) {
    return (
      <>
        <LoginForm onLogin={handleLogin} />
        <button
          onClick={() => setView('home')}
          className="fixed top-4 left-4 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
        >
          ← Volver al inicio
        </button>
        <Toaster />
      </>
    );
  }

  // Render Admin Dashboard
  const selectedBooking = selectedBookingId ? getBookingById(selectedBookingId) : null;

  return (
    <div className="min-h-screen bg-slate-950 flex">
      <Sidebar
        currentView={adminView}
        onChangeView={setAdminView}
        onLogout={handleLogout}
        adminName={username || 'Admin'}
      />
      
      <main className="flex-1 p-8 overflow-auto">
        <div className="max-w-6xl mx-auto">
          {adminView === 'dashboard' && (
            selectedBooking ? (
              <BookingDetail
                booking={selectedBooking}
                onBack={handleBackToDashboard}
                onUpdateStatus={handleUpdateBookingStatus}
              />
            ) : (
              <Dashboard
                stats={stats}
                upcomingBookings={upcomingBookings}
                onViewBooking={handleViewBooking}
              />
            )
          )}

          {adminView === 'new-booking' && (
            <NewBooking
              onBack={() => setAdminView('dashboard')}
              onSave={handleSaveNewBooking}
            />
          )}

          {adminView === 'calendar' && (
            <CalendarView
              bookings={bookings}
              onBack={() => setAdminView('dashboard')}
              onViewBooking={(id) => {
                setSelectedBookingId(id);
                setAdminView('dashboard');
              }}
            />
          )}

          {adminView === 'settings' && (
            <Settings
              onBack={() => setAdminView('dashboard')}
            />
          )}
        </div>
      </main>
      
      <Toaster />
    </div>
  );
}

export default App;
