import { createClient } from '@supabase/supabase-js';
import type { Booking, VehicleType } from '@/types';

// Replace these with your actual Supabase credentials
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseKey);

// Database types
export interface DatabaseBooking {
  id: string;
  vehicle: VehicleType;
  services: string[];
  date: string;
  time: string;
  customer_name: string;
  customer_whatsapp: string;
  customer_patent: string;
  customer_brand: string;
  customer_model: string;
  status: 'pending' | 'waiting_deposit' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  total: number;
  duration: number;
  created_at: string;
}

// Convert database booking to app booking format
export function dbToBooking(dbBooking: DatabaseBooking): Booking {
  return {
    id: dbBooking.id,
    vehicle: dbBooking.vehicle,
    services: dbBooking.services,
    date: dbBooking.date,
    time: dbBooking.time,
    customer: {
      name: dbBooking.customer_name,
      whatsapp: dbBooking.customer_whatsapp,
      patent: dbBooking.customer_patent,
      brand: dbBooking.customer_brand,
      model: dbBooking.customer_model,
    },
    status: dbBooking.status,
    total: dbBooking.total,
    duration: dbBooking.duration,
    createdAt: dbBooking.created_at,
  };
}

// Convert app booking to database format
export function bookingToDb(booking: Omit<Booking, 'id' | 'createdAt'> & { id?: string; createdAt?: string }): Omit<DatabaseBooking, 'id' | 'created_at'> & { id?: string; created_at?: string } {
  return {
    id: booking.id,
    vehicle: booking.vehicle,
    services: booking.services,
    date: booking.date,
    time: booking.time,
    customer_name: booking.customer.name,
    customer_whatsapp: booking.customer.whatsapp,
    customer_patent: booking.customer.patent,
    customer_brand: booking.customer.brand,
    customer_model: booking.customer.model,
    status: booking.status,
    total: booking.total,
    duration: booking.duration,
    created_at: booking.createdAt,
  };
}
