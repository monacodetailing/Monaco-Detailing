import type { Vehicle, Service } from '@/types';

export const VEHICLES: Vehicle[] = [
  { id: 'autos', name: 'Autos', description: 'Sedan, Hatchback, Citycar', icon: '🚗' },
  { id: 'suv', name: 'SUV', description: 'Camionetas SUV', icon: '🚐' },
  { id: 'pickup', name: 'Pick Up', description: 'Camionetas Pick Up', icon: '🛻' },
];

// Services with prices by vehicle type
export const SERVICES: Service[] = [
  // LAVADO PREMIUM
  { 
    id: 'lavado-premium-autos', 
    name: 'Lavado Premium', 
    description: 'Limpieza profunda de pasaruedas / llantas / insignias / descontaminación total / eliminación de marcas de agua en vidrios / shampo PH neutro / reacondicionamiento de plásticos',
    price: 90000, 
    duration: 120,
    vehicleType: 'autos'
  },
  { 
    id: 'lavado-premium-suv', 
    name: 'Lavado Premium', 
    description: 'Limpieza profunda de pasaruedas / llantas / insignias / descontaminación total / eliminación de marcas de agua en vidrios / shampo PH neutro / reacondicionamiento de plásticos',
    price: 120000, 
    duration: 150,
    vehicleType: 'suv'
  },
  { 
    id: 'lavado-premium-pickup', 
    name: 'Lavado Premium', 
    description: 'Limpieza profunda de pasaruedas / llantas / insignias / descontaminación total / eliminación de marcas de agua en vidrios / shampo PH neutro / reacondicionamiento de plásticos',
    price: 120000, 
    duration: 150,
    vehicleType: 'pickup'
  },

  // INTERIOR AL DETALLE
  { 
    id: 'interior-detalle-autos', 
    name: 'Interior al Detalle', 
    description: 'Aspirado profundo / limpiezas de techo y tapizados / descontaminación de habitáculo y reacondicionamiento de plásticos',
    price: 140000, 
    duration: 180,
    vehicleType: 'autos'
  },
  { 
    id: 'interior-detalle-suv', 
    name: 'Interior al Detalle', 
    description: 'Aspirado profundo / limpiezas de techo y tapizados / descontaminación de habitáculo y reacondicionamiento de plásticos',
    price: 190000, 
    duration: 210,
    vehicleType: 'suv'
  },
  { 
    id: 'interior-detalle-pickup', 
    name: 'Interior al Detalle', 
    description: 'Aspirado profundo / limpiezas de techo y tapizados / descontaminación de habitáculo y reacondicionamiento de plásticos',
    price: 190000, 
    duration: 210,
    vehicleType: 'pickup'
  },

  // MOTOR A VAPOR
  { 
    id: 'motor-vapor-autos', 
    name: 'Motor a Vapor', 
    description: 'Limpieza de motor con vapor',
    price: 70000, 
    duration: 60,
    vehicleType: 'autos'
  },
  { 
    id: 'motor-vapor-suv', 
    name: 'Motor a Vapor', 
    description: 'Limpieza de motor con vapor',
    price: 80000, 
    duration: 75,
    vehicleType: 'suv'
  },
  { 
    id: 'motor-vapor-pickup', 
    name: 'Motor a Vapor', 
    description: 'Limpieza de motor con vapor',
    price: 80000, 
    duration: 75,
    vehicleType: 'pickup'
  },

  // COMBO COMPLETO
  { 
    id: 'combo-completo-autos', 
    name: 'Combo Completo', 
    description: 'Lavado Premium + Interior al Detalle + Motor a Vapor + Abrillantado con Cera Hidrofóbica',
    price: 400000, 
    duration: 360,
    vehicleType: 'autos'
  },
  { 
    id: 'combo-completo-suv', 
    name: 'Combo Completo', 
    description: 'Lavado Premium + Interior al Detalle + Motor a Vapor + Abrillantado con Cera Hidrofóbica',
    price: 440000, 
    duration: 420,
    vehicleType: 'suv'
  },
  { 
    id: 'combo-completo-pickup', 
    name: 'Combo Completo', 
    description: 'Lavado Premium + Interior al Detalle + Motor a Vapor + Abrillantado con Cera Hidrofóbica',
    price: 480000, 
    duration: 420,
    vehicleType: 'pickup'
  },

  // PULIDO DE ÓPTICAS
  { 
    id: 'pulido-opticas-autos', 
    name: 'Pulido de Ópticas', 
    description: 'Lijado - Pulido - Sellado. Par de ópticas',
    price: 50000, 
    duration: 90,
    vehicleType: 'autos'
  },
  { 
    id: 'pulido-opticas-suv', 
    name: 'Pulido de Ópticas', 
    description: 'Lijado - Pulido - Sellado. Par de ópticas',
    price: 60000, 
    duration: 90,
    vehicleType: 'suv'
  },
  { 
    id: 'pulido-opticas-pickup', 
    name: 'Pulido de Ópticas', 
    description: 'Lijado - Pulido - Sellado. Par de ópticas',
    price: 60000, 
    duration: 90,
    vehicleType: 'pickup'
  },

  // TRATAMIENTOS - ACRÍLICO
  { 
    id: 'acrilico-autos', 
    name: 'Acrílico Menzerna', 
    description: 'Menzerna - 3D Detailing - Duración 6 meses',
    price: 320000, 
    duration: 240,
    vehicleType: 'autos'
  },
  { 
    id: 'acrilico-suv', 
    name: 'Acrílico Menzerna', 
    description: 'Menzerna - 3D Detailing - Duración 6 meses',
    price: 400000, 
    duration: 300,
    vehicleType: 'suv'
  },
  { 
    id: 'acrilico-pickup', 
    name: 'Acrílico Menzerna', 
    description: 'Menzerna - 3D Detailing - Duración 6 meses',
    price: 450000, 
    duration: 300,
    vehicleType: 'pickup'
  },

  // TRATAMIENTOS - CERÁMICO 2 AÑOS
  { 
    id: 'ceramico-2anos-autos', 
    name: 'Cerámico Gyeon (2 años)', 
    description: 'Gyeon - 3D Detailing - Duración 2 años',
    price: 500000, 
    duration: 300,
    vehicleType: 'autos'
  },
  { 
    id: 'ceramico-2anos-suv', 
    name: 'Cerámico Gyeon (2 años)', 
    description: 'Gyeon - 3D Detailing - Duración 2 años',
    price: 700000, 
    duration: 360,
    vehicleType: 'suv'
  },
  { 
    id: 'ceramico-2anos-pickup', 
    name: 'Cerámico Gyeon (2 años)', 
    description: 'Gyeon - 3D Detailing - Duración 2 años',
    price: 800000, 
    duration: 360,
    vehicleType: 'pickup'
  },

  // TRATAMIENTOS - CERÁMICO 4 AÑOS
  { 
    id: 'ceramico-4anos-autos', 
    name: 'Cerámico Carpro (4 años)', 
    description: 'Carpro - Gyeon - 3D Detailing - Duración 4 años',
    price: 700000, 
    duration: 360,
    vehicleType: 'autos'
  },
  { 
    id: 'ceramico-4anos-suv', 
    name: 'Cerámico Carpro (4 años)', 
    description: 'Carpro - Gyeon - 3D Detailing - Duración 4 años',
    price: 900000, 
    duration: 420,
    vehicleType: 'suv'
  },
  { 
    id: 'ceramico-4anos-pickup', 
    name: 'Cerámico Carpro (4 años)', 
    description: 'Carpro - Gyeon - 3D Detailing - Duración 4 años',
    price: 1000000, 
    duration: 420,
    vehicleType: 'pickup'
  },

  // PPF - NANOGLASS
  { 
    id: 'nanoglass-autos', 
    name: 'Nanoglass PPF', 
    description: 'Durabilidad 10 años - 216 micrones de espesor - autoregenerativo',
    price: 2600000, 
    duration: 1440,
    vehicleType: 'autos'
  },
  { 
    id: 'nanoglass-suv', 
    name: 'Nanoglass PPF', 
    description: 'Durabilidad 10 años - 216 micrones de espesor - autoregenerativo',
    price: 2800000, 
    duration: 1680,
    vehicleType: 'suv'
  },
  { 
    id: 'nanoglass-pickup', 
    name: 'Nanoglass PPF', 
    description: 'Durabilidad 10 años - 216 micrones de espesor - autoregenerativo',
    price: 2800000, 
    duration: 1680,
    vehicleType: 'pickup'
  },

  // PPF - NANOGLASS MATTE
  { 
    id: 'nanoglass-matte-autos', 
    name: 'Nanoglass Matte PPF', 
    description: 'Durabilidad 10 años - 195 micrones de espesor - autoregenerativo',
    price: 2800000, 
    duration: 1440,
    vehicleType: 'autos'
  },
  { 
    id: 'nanoglass-matte-suv', 
    name: 'Nanoglass Matte PPF', 
    description: 'Durabilidad 10 años - 195 micrones de espesor - autoregenerativo',
    price: 3000000, 
    duration: 1680,
    vehicleType: 'suv'
  },
  { 
    id: 'nanoglass-matte-pickup', 
    name: 'Nanoglass Matte PPF', 
    description: 'Durabilidad 10 años - 195 micrones de espesor - autoregenerativo',
    price: 3000000, 
    duration: 1680,
    vehicleType: 'pickup'
  },

  // PPF - NANOGLASS BLACK
  { 
    id: 'nanoglass-black-autos', 
    name: 'Nanoglass Black PPF', 
    description: 'Durabilidad 10 años - 195 micrones de espesor - autoregenerativo',
    price: 2900000, 
    duration: 1440,
    vehicleType: 'autos'
  },
  { 
    id: 'nanoglass-black-suv', 
    name: 'Nanoglass Black PPF', 
    description: 'Durabilidad 10 años - 195 micrones de espesor - autoregenerativo',
    price: 3100000, 
    duration: 1680,
    vehicleType: 'suv'
  },
  { 
    id: 'nanoglass-black-pickup', 
    name: 'Nanoglass Black PPF', 
    description: 'Durabilidad 10 años - 195 micrones de espesor - autoregenerativo',
    price: 3100000, 
    duration: 1680,
    vehicleType: 'pickup'
  },
];

export const BUSINESS_INFO = {
  name: 'Monaco Detailing',
  slogan: 'Cuidado profesional para tu vehículo',
  phone: '+54 9 11 3020-4512',
  email: 'contacto@monacodetailing.com.ar',
  address: 'Carlos Francisco Melo 3685, Vicente López, GBA',
  hours: {
    weekday: '09:00 - 19:00',
    saturday: '09:00 - 14:00',
  },
  whatsappMessage: (booking: any) => {
    const vehicle = VEHICLES.find(v => v.id === booking.vehicle);
    return `Hola ${booking.customer.name}! Te escribimos de "Monaco Detailing". Recibimos tu solicitud para el "${vehicle?.name}" (Patente: ${booking.customer.patent}). Para confirmar la fecha del "${new Date(booking.date).toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' })} a las ${booking.time}hs" necesitamos una seña inicial.`;
  },
};

export const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'admin123',
};

export const AVAILABLE_HOURS = [
  '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', 
  '1:00 PM', '2:00 PM', '3:00 PM'
];
