import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { supabase, dbToBooking, bookingToDb } from '@/lib/supabase';
import type { Booking } from '@/types';
import { toast } from 'sonner';

interface BookingContextType {
  bookings: Booking[];
  isLoaded: boolean;
  isLoading: boolean;
  addBooking: (booking: Omit<Booking, 'id' | 'createdAt' | 'status'>) => Promise<Booking | null>;
  updateBookingStatus: (bookingId: string, status: Booking['status']) => Promise<void>;
  deleteBooking: (bookingId: string) => Promise<void>;
  getBookingById: (bookingId: string) => Booking | undefined;
  getBookingsByDate: (date: string) => Booking[];
  getUpcomingBookings: () => Booking[];
  getStats: () => { monthlyIncome: number; monthlyBookings: number; todayBookings: number };
  refreshBookings: () => Promise<void>;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export function BookingProvider({ children }: { children: ReactNode }) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch all bookings from Supabase
  const fetchBookings = useCallback(async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching bookings:', error);
        toast.error('Error al cargar las reservas');
        return;
      }

      if (data) {
        const convertedBookings = data.map(dbToBooking);
        setBookings(convertedBookings);
      }
    } catch (err) {
      console.error('Error:', err);
    } finally {
      setIsLoading(false);
      setIsLoaded(true);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  // Subscribe to real-time changes
  useEffect(() => {
    const subscription = supabase
      .channel('bookings-channel')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings' },
        () => {
          // Refresh bookings when any change occurs
          fetchBookings();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchBookings]);

  // Add a new booking
  const addBooking = useCallback(async (booking: Omit<Booking, 'id' | 'createdAt' | 'status'>): Promise<Booking | null> => {
    try {
      const newBookingData = {
        ...bookingToDb(booking as any),
        status: 'pending' as const,
        created_at: new Date().toISOString(),
      };

      const { data, error } = await supabase
        .from('bookings')
        .insert([newBookingData])
        .select()
        .single();

      if (error) {
        console.error('Error adding booking:', error);
        toast.error('Error al guardar la reserva');
        return null;
      }

      if (data) {
        const newBooking = dbToBooking(data);
        setBookings(prev => [newBooking, ...prev]);
        toast.success('Reserva creada correctamente');
        return newBooking;
      }
      return null;
    } catch (err) {
      console.error('Error:', err);
      toast.error('Error al guardar la reserva');
      return null;
    }
  }, []);

  // Update booking status
  const updateBookingStatus = useCallback(async (bookingId: string, status: Booking['status']) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status })
        .eq('id', bookingId);

      if (error) {
        console.error('Error updating booking:', error);
        toast.error('Error al actualizar la reserva');
        return;
      }

      setBookings(prev =>
        prev.map(booking =>
          booking.id === bookingId ? { ...booking, status } : booking
        )
      );
    } catch (err) {
      console.error('Error:', err);
      toast.error('Error al actualizar la reserva');
    }
  }, []);

  // Delete a booking
  const deleteBooking = useCallback(async (bookingId: string) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .delete()
        .eq('id', bookingId);

      if (error) {
        console.error('Error deleting booking:', error);
        toast.error('Error al eliminar la reserva');
        return;
      }

      setBookings(prev => prev.filter(booking => booking.id !== bookingId));
      toast.success('Reserva eliminada');
    } catch (err) {
      console.error('Error:', err);
      toast.error('Error al eliminar la reserva');
    }
  }, []);

  // Get booking by ID
  const getBookingById = useCallback((bookingId: string) => {
    return bookings.find(booking => booking.id === bookingId);
  }, [bookings]);

  // Get bookings by date
  const getBookingsByDate = useCallback((date: string) => {
    return bookings.filter(booking => booking.date === date);
  }, [bookings]);

  // Get upcoming bookings
  const getUpcomingBookings = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    return bookings
      .filter(booking => booking.date >= today && booking.status !== 'cancelled')
      .sort((a, b) => {
        const dateCompare = a.date.localeCompare(b.date);
        if (dateCompare !== 0) return dateCompare;
        return a.time.localeCompare(b.time);
      });
  }, [bookings]);

  // Get stats
  const getStats = useCallback(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const today = now.toISOString().split('T')[0];

    const monthlyBookings = bookings.filter(booking => {
      const bookingDate = new Date(booking.date);
      return (
        bookingDate.getMonth() === currentMonth &&
        bookingDate.getFullYear() === currentYear &&
        booking.status !== 'cancelled'
      );
    });

    const monthlyIncome = monthlyBookings.reduce((sum, booking) => sum + booking.total, 0);

    const todayBookings = bookings.filter(
      booking => booking.date === today && booking.status !== 'cancelled'
    ).length;

    return {
      monthlyIncome,
      monthlyBookings: monthlyBookings.length,
      todayBookings,
    };
  }, [bookings]);

  // Refresh bookings
  const refreshBookings = useCallback(async () => {
    await fetchBookings();
  }, [fetchBookings]);

  return (
    <BookingContext.Provider
      value={{
        bookings,
        isLoaded,
        isLoading,
        addBooking,
        updateBookingStatus,
        deleteBooking,
        getBookingById,
        getBookingsByDate,
        getUpcomingBookings,
        getStats,
        refreshBookings,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
}

export function useBookingContext() {
  const context = useContext(BookingContext);
  if (context === undefined) {
    throw new Error('useBookingContext must be used within a BookingProvider');
  }
  return context;
}
