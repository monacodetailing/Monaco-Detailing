import type { BookingStep } from '@/types';
import { Car, Wrench, Calendar, User, CheckCircle } from 'lucide-react';

interface ProgressBarProps {
  currentStep: BookingStep;
}

const steps = [
  { id: 'vehicle', label: 'Vehículo', icon: Car },
  { id: 'services', label: 'Servicio', icon: Wrench },
  { id: 'date', label: 'Fecha', icon: Calendar },
  { id: 'data', label: 'Datos', icon: User },
  { id: 'confirm', label: 'OK', icon: CheckCircle },
] as const;

export function ProgressBar({ currentStep }: ProgressBarProps) {
  const getStepIndex = (step: BookingStep) => {
    const index = steps.findIndex(s => s.id === step);
    return index === -1 ? steps.length : index;
  };

  const currentIndex = getStepIndex(currentStep);

  return (
    <div className="flex items-center justify-between mb-8">
      {steps.map((step, index) => {
        const Icon = step.icon;
        const isActive = index <= currentIndex;
        const isCurrent = index === currentIndex;

        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isCurrent
                    ? 'bg-amber-500 text-slate-900'
                    : isActive
                    ? 'bg-amber-500/20 text-amber-500'
                    : 'bg-slate-800 text-slate-500'
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span
                className={`text-xs mt-2 font-medium ${
                  isActive ? 'text-amber-500' : 'text-slate-500'
                }`}
              >
                {step.label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div
                className={`flex-1 h-0.5 mx-2 transition-all duration-300 ${
                  index < currentIndex ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
