import { useState } from 'react';
import { X } from 'lucide-react';
import { useBooking } from '@/hooks/useBooking';
import { useBookingContext } from '@/context/BookingContext';
import { ProgressBar } from './ProgressBar';
import { VehicleSelection } from './VehicleSelection';
import { ServiceSelection } from './ServiceSelection';
import { DateSelection } from './DateSelection';
import { CustomerData } from './CustomerData';
import { Confirmation } from './Confirmation';
import { SuccessView } from './SuccessView';
import { SERVICES } from '@/data/constants';
import type { Booking } from '@/types';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function BookingModal({ isOpen, onClose }: BookingModalProps) {
  const {
    currentStep,
    bookingData,
    selectVehicle,
    toggleService,
    selectDate,
    selectTime,
    updateCustomerData,
    nextStep,
    prevStep,
    resetBooking,
    canProceed,
    setCurrentStep,
  } = useBooking();

  const { addBooking } = useBookingContext();

  const [createdBooking, setCreatedBooking] = useState<Booking | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleConfirm = async () => {
    setIsSubmitting(true);
    
    const total = bookingData.services.reduce((sum, sId) => {
      const service = SERVICES.find(s => s.id === sId);
      return sum + (service?.price || 0);
    }, 0);

    const duration = bookingData.services.reduce((sum, sId) => {
      const service = SERVICES.find(s => s.id === sId);
      return sum + (service?.duration || 0);
    }, 0);

    const newBooking = await addBooking({
      vehicle: bookingData.vehicle!,
      services: bookingData.services,
      date: bookingData.date!.toISOString().split('T')[0],
      time: bookingData.time!,
      customer: bookingData.customer,
      total,
      duration,
    });

    setIsSubmitting(false);
    
    if (newBooking) {
      setCreatedBooking(newBooking);
      setCurrentStep('success');
    }
  };

  const handleClose = () => {
    resetBooking();
    setCreatedBooking(null);
    onClose();
  };

  const handleNewBooking = () => {
    resetBooking();
    setCreatedBooking(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 rounded-3xl w-full max-w-lg h-[90vh] flex flex-col border border-slate-800 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-slate-900">M</span>
            </div>
            <div>
              <h2 className="text-white font-semibold">Monaco Detailing</h2>
              <p className="text-slate-500 text-xs">Reservá tu turno</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        {/* Content - Scrollable */}
        <div className="flex-1 overflow-y-auto p-6">
          {currentStep !== 'success' && <ProgressBar currentStep={currentStep} />}

          <div className="pb-4">
            {currentStep === 'vehicle' && (
              <VehicleSelection
                selectedVehicle={bookingData.vehicle}
                onSelect={selectVehicle}
              />
            )}

            {currentStep === 'services' && (
              <ServiceSelection
                selectedServices={bookingData.services}
                onToggle={toggleService}
                vehicleType={bookingData.vehicle}
              />
            )}

            {currentStep === 'date' && (
              <DateSelection
                selectedDate={bookingData.date}
                selectedTime={bookingData.time}
                onSelectDate={selectDate}
                onSelectTime={selectTime}
              />
            )}

            {currentStep === 'data' && (
              <CustomerData
                data={bookingData.customer}
                onUpdate={updateCustomerData}
              />
            )}

            {currentStep === 'confirm' && (
              <Confirmation
                bookingData={bookingData}
                onConfirm={handleConfirm}
                onEdit={prevStep}
                isSubmitting={isSubmitting}
              />
            )}

            {currentStep === 'success' && createdBooking && (
              <SuccessView
                booking={createdBooking}
                onNewBooking={handleNewBooking}
                onGoHome={handleClose}
              />
            )}
          </div>
        </div>

        {/* Footer Navigation - Fixed at bottom */}
        {currentStep !== 'confirm' && currentStep !== 'success' && (
          <div className="p-6 border-t border-slate-800 flex gap-3 flex-shrink-0 bg-slate-900">
            {currentStep !== 'vehicle' && (
              <button
                onClick={prevStep}
                className="px-6 py-3 rounded-xl bg-slate-800 text-white font-medium hover:bg-slate-700 transition-colors flex items-center gap-2"
              >
                ← Volver
              </button>
            )}
            <button
              onClick={nextStep}
              disabled={!canProceed()}
              className={`flex-1 py-3 px-4 rounded-xl font-medium transition-colors flex items-center justify-center gap-2 ${
                canProceed()
                  ? 'bg-amber-500 text-slate-900 hover:bg-amber-400'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              {currentStep === 'data' ? 'Siguiente →' : 'Continuar →'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
