import { SERVICES } from '@/data/constants';
import type { VehicleType } from '@/types';
import { Check, Clock } from 'lucide-react';

interface ServiceSelectionProps {
  selectedServices: string[];
  onToggle: (serviceId: string) => void;
  vehicleType: VehicleType | null;
}

export function ServiceSelection({ selectedServices, onToggle, vehicleType }: ServiceSelectionProps) {
  // Filter services by vehicle type
  const filteredServices = vehicleType 
    ? SERVICES.filter(s => s.vehicleType === vehicleType)
    : [];

  const totalPrice = selectedServices.reduce((sum, serviceId) => {
    const service = SERVICES.find(s => s.id === serviceId);
    return sum + (service?.price || 0);
  }, 0);

  const totalDuration = selectedServices.reduce((sum, serviceId) => {
    const service = SERVICES.find(s => s.id === serviceId);
    return sum + (service?.duration || 0);
  }, 0);

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins}min`;
    if (mins === 0) return `${hours}h`;
    return `${hours}h ${mins}min`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white mb-1">
            2. Seleccioná los servicios
          </h3>
          <p className="text-slate-400 text-sm">Podés elegir uno o más</p>
        </div>
      </div>

      <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
        {filteredServices.map((service) => {
          const isSelected = selectedServices.includes(service.id);
          
          return (
            <button
              key={service.id}
              onClick={() => onToggle(service.id)}
              className={`w-full p-4 rounded-xl border-2 transition-all duration-200 flex items-center justify-between ${
                isSelected
                  ? 'border-amber-500 bg-amber-500/10'
                  : 'border-slate-700 bg-slate-800/50 hover:border-slate-600 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-start gap-3 text-left">
                <div
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center mt-0.5 ${
                    isSelected
                      ? 'bg-amber-500 border-amber-500'
                      : 'border-slate-500'
                  }`}
                >
                  {isSelected && <Check className="w-3 h-3 text-slate-900" />}
                </div>
                <div className="flex-1">
                  <div className="font-medium text-white">{service.name}</div>
                  <div className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                    <Clock className="w-3 h-3" />
                    {service.duration >= 60 
                      ? `${Math.floor(service.duration / 60)}h${service.duration % 60 ? ` ${service.duration % 60}min` : ''}`
                      : `${service.duration} min`
                    }
                  </div>
                  <div className="text-xs text-slate-500 mt-1">{service.description}</div>
                </div>
              </div>
              <div className="text-amber-500 font-semibold whitespace-nowrap ml-4">
                ${service.price.toLocaleString()}
              </div>
            </button>
          );
        })}
      </div>

      {selectedServices.length > 0 && (
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Total estimado</span>
            <span className="text-amber-500 font-bold text-xl">
              ${totalPrice.toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between items-center mt-1">
            <span className="text-slate-500 text-sm">Duración total</span>
            <span className="text-slate-400 text-sm">{formatDuration(totalDuration)}</span>
          </div>
        </div>
      )}
    </div>
  );
}
