import { useState } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Calendar as CalendarIcon, Clock } from 'lucide-react';
import type { Booking } from '@/types';
import { VEHICLES, SERVICES } from '@/data/constants';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isToday, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

interface CalendarViewProps {
  bookings: Booking[];
  onBack: () => void;
  onViewBooking: (bookingId: string) => void;
}

export function CalendarView({ bookings, onBack, onViewBooking }: CalendarViewProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const weekDays = ['DO', 'LU', 'MA', 'MI', 'JU', 'VI', 'SA'];

  const prevMonth = () => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  const nextMonth = () => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));

  // Get bookings for a specific date
  const getBookingsForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return bookings.filter(b => b.date === dateStr && b.status !== 'cancelled');
  };

  // Get selected date bookings
  const selectedDateBookings = selectedDate 
    ? bookings.filter(b => b.date === selectedDate && b.status !== 'cancelled')
    : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate-400" />
        </button>
        <h2 className="text-xl font-bold text-white">Calendario de Turnos</h2>
      </div>

      {/* Calendar */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        {/* Month Navigation */}
        <div className="flex items-center justify-between mb-6">
          <button onClick={prevMonth} className="p-2 hover:bg-slate-700 rounded-lg">
            <ChevronLeft className="w-5 h-5 text-slate-400" />
          </button>
          <span className="text-white font-semibold text-lg capitalize">
            {format(currentMonth, 'MMMM yyyy', { locale: es })}
          </span>
          <button onClick={nextMonth} className="p-2 hover:bg-slate-700 rounded-lg">
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        {/* Week Days */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {weekDays.map(day => (
            <div key={day} className="text-center text-xs text-slate-500 py-2">{day}</div>
          ))}
        </div>

        {/* Days */}
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: getDay(monthStart) }).map((_, i) => (
            <div key={`empty-${i}`} />
          ))}
          {days.map(day => {
            const dayBookings = getBookingsForDate(day);
            const hasBookings = dayBookings.length > 0;
            const isSelected = selectedDate === day.toISOString().split('T')[0];
            const isTodayDate = isToday(day);

            return (
              <button
                key={day.toISOString()}
                onClick={() => setSelectedDate(day.toISOString().split('T')[0])}
                className={`
                  aspect-square rounded-lg text-sm relative p-1
                  ${isSelected ? 'bg-amber-500 text-slate-900' : ''}
                  ${!isSelected && isTodayDate ? 'bg-slate-700 text-white' : ''}
                  ${!isSelected && !isTodayDate ? 'hover:bg-slate-800 text-slate-300' : ''}
                `}
              >
                <span className="absolute top-1 left-1">{format(day, 'd')}</span>
                {hasBookings && (
                  <div className="absolute bottom-1 right-1 flex gap-0.5">
                    {dayBookings.slice(0, 3).map((_, i) => (
                      <div key={i} className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-slate-900' : 'bg-amber-500'}`} />
                    ))}
                    {dayBookings.length > 3 && (
                      <span className={`text-[8px] ${isSelected ? 'text-slate-900' : 'text-amber-500'}`}>+</span>
                    )}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Date Bookings */}
      {selectedDate && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-amber-500" />
            Turnos del {format(parseISO(selectedDate), 'd MMMM', { locale: es })}
          </h3>
          
          {selectedDateBookings.length === 0 ? (
            <p className="text-slate-500 text-center py-4">No hay turnos para esta fecha</p>
          ) : (
            <div className="space-y-2">
              {selectedDateBookings.map(booking => {
                const vehicle = VEHICLES.find(v => v.id === booking.vehicle);
                const serviceNames = booking.services
                  .map(sId => SERVICES.find(s => s.id === sId)?.name)
                  .filter(Boolean)
                  .slice(0, 2);

                return (
                  <button
                    key={booking.id}
                    onClick={() => onViewBooking(booking.id)}
                    className="w-full bg-slate-800/50 hover:bg-slate-800 rounded-xl p-4 border border-slate-700 transition-colors flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{vehicle?.icon}</div>
                      <div className="text-left">
                        <p className="text-white font-medium">{booking.customer.name}</p>
                        <p className="text-slate-400 text-sm">{vehicle?.name}</p>
                        <div className="flex gap-1 mt-1">
                          {serviceNames.map((name, i) => (
                            <span key={i} className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded">{name}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-amber-500 font-semibold flex items-center gap-1">
                        <Clock className="w-4 h-4" /> {booking.time}
                      </p>
                      <p className="text-slate-400 text-sm">${booking.total.toLocaleString()}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
