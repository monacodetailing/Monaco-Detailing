import { useState } from 'react';
import { ArrowLeft, Calendar, Clock, Car, User, Phone, Hash, CheckCircle } from 'lucide-react';
import { VEHICLES, SERVICES } from '@/data/constants';
import type { VehicleType } from '@/types';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface NewBookingProps {
  onBack: () => void;
  onSave: (booking: any) => void;
}

export function NewBooking({ onBack, onSave }: NewBookingProps) {
  const [step, setStep] = useState(1);
  const [vehicle, setVehicle] = useState<VehicleType | null>(null);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [customer, setCustomer] = useState({
    name: '',
    whatsapp: '',
    patent: '',
    brand: '',
    model: '',
  });

  const filteredServices = vehicle 
    ? SERVICES.filter(s => s.vehicleType === vehicle)
    : [];

  const toggleService = (serviceId: string) => {
    setSelectedServices(prev =>
      prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const totalPrice = selectedServices.reduce((sum, sId) => {
    const service = SERVICES.find(s => s.id === sId);
    return sum + (service?.price || 0);
  }, 0);

  const handleSave = () => {
    const duration = selectedServices.reduce((sum, sId) => {
      const service = SERVICES.find(s => s.id === sId);
      return sum + (service?.duration || 0);
    }, 0);

    onSave({
      vehicle,
      services: selectedServices,
      date,
      time,
      customer,
      total: totalPrice,
      duration,
    });
  };

  const availableHours = ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate-400" />
        </button>
        <h2 className="text-xl font-bold text-white">Nuevo Turno</h2>
      </div>

      {/* Progress */}
      <div className="flex gap-2">
        {[1, 2, 3, 4].map(s => (
          <div
            key={s}
            className={`flex-1 h-2 rounded-full ${s <= step ? 'bg-amber-500' : 'bg-slate-700'}`}
          />
        ))}
      </div>

      {/* Step 1: Vehicle */}
      {step === 1 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">1. Seleccioná el vehículo</h3>
          <div className="grid grid-cols-3 gap-3">
            {VEHICLES.map(v => (
              <button
                key={v.id}
                onClick={() => setVehicle(v.id)}
                className={`p-4 rounded-xl border-2 transition-all text-center ${
                  vehicle === v.id
                    ? 'border-amber-500 bg-amber-500/10'
                    : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
                }`}
              >
                <div className="text-3xl mb-2">{v.icon}</div>
                <div className="font-medium text-white text-sm">{v.name}</div>
              </button>
            ))}
          </div>
          <button
            onClick={() => setStep(2)}
            disabled={!vehicle}
            className="w-full py-3 bg-amber-500 text-slate-900 rounded-xl font-medium disabled:bg-slate-700 disabled:text-slate-500"
          >
            Continuar →
          </button>
        </div>
      )}

      {/* Step 2: Services */}
      {step === 2 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">2. Seleccioná los servicios</h3>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {filteredServices.map(service => (
              <button
                key={service.id}
                onClick={() => toggleService(service.id)}
                className={`w-full p-3 rounded-xl border-2 transition-all flex justify-between items-center ${
                  selectedServices.includes(service.id)
                    ? 'border-amber-500 bg-amber-500/10'
                    : 'border-slate-700 bg-slate-800/50'
                }`}
              >
                <div className="text-left">
                  <div className="text-white font-medium">{service.name}</div>
                  <div className="text-slate-400 text-xs">{service.description.slice(0, 50)}...</div>
                </div>
                <div className="text-amber-500 font-semibold">${service.price.toLocaleString()}</div>
              </button>
            ))}
          </div>
          {selectedServices.length > 0 && (
            <div className="bg-slate-800 rounded-xl p-3">
              <div className="flex justify-between">
                <span className="text-slate-400">Total:</span>
                <span className="text-amber-500 font-bold">${totalPrice.toLocaleString()}</span>
              </div>
            </div>
          )}
          <div className="flex gap-3">
            <button onClick={() => setStep(1)} className="px-6 py-3 bg-slate-800 text-white rounded-xl">← Volver</button>
            <button
              onClick={() => setStep(3)}
              disabled={selectedServices.length === 0}
              className="flex-1 py-3 bg-amber-500 text-slate-900 rounded-xl font-medium disabled:bg-slate-700"
            >
              Continuar →
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Date & Time */}
      {step === 3 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">3. Fecha y hora</h3>
          <div className="space-y-3">
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Calendar className="w-4 h-4" /> Fecha
              </Label>
              <Input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4" /> Hora
              </Label>
              <div className="grid grid-cols-3 gap-2">
                {availableHours.map(h => (
                  <button
                    key={h}
                    onClick={() => setTime(h)}
                    className={`py-2 rounded-lg text-sm ${
                      time === h
                        ? 'bg-amber-500 text-slate-900'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {h}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(2)} className="px-6 py-3 bg-slate-800 text-white rounded-xl">← Volver</button>
            <button
              onClick={() => setStep(4)}
              disabled={!date || !time}
              className="flex-1 py-3 bg-amber-500 text-slate-900 rounded-xl font-medium disabled:bg-slate-700"
            >
              Continuar →
            </button>
          </div>
        </div>
      )}

      {/* Step 4: Customer Data */}
      {step === 4 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">4. Datos del cliente</h3>
          <div className="space-y-3">
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <User className="w-4 h-4" /> Nombre
              </Label>
              <Input
                value={customer.name}
                onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                placeholder="Juan Pérez"
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Phone className="w-4 h-4" /> WhatsApp
              </Label>
              <Input
                value={customer.whatsapp}
                onChange={(e) => setCustomer({ ...customer, whatsapp: e.target.value })}
                placeholder="11 3020 4512"
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Car className="w-4 h-4" /> Marca
              </Label>
              <Input
                value={customer.brand}
                onChange={(e) => setCustomer({ ...customer, brand: e.target.value })}
                placeholder="Toyota"
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Car className="w-4 h-4" /> Modelo
              </Label>
              <Input
                value={customer.model}
                onChange={(e) => setCustomer({ ...customer, model: e.target.value })}
                placeholder="Corolla"
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Hash className="w-4 h-4" /> Patente
              </Label>
              <Input
                value={customer.patent}
                onChange={(e) => setCustomer({ ...customer, patent: e.target.value.toUpperCase() })}
                placeholder="ABC123"
                className="bg-slate-800 border-slate-700 text-white uppercase"
              />
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(3)} className="px-6 py-3 bg-slate-800 text-white rounded-xl">← Volver</button>
            <button
              onClick={handleSave}
              disabled={!customer.name || !customer.whatsapp || !customer.brand || !customer.model || !customer.patent}
              className="flex-1 py-3 bg-green-500 text-white rounded-xl font-medium disabled:bg-slate-700 flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              Guardar Turno
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
