import { useState } from 'react';
import { ArrowLeft, Save, Store, Clock, Phone, MapPin, User, Lock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BUSINESS_INFO, ADMIN_CREDENTIALS } from '@/data/constants';

interface SettingsProps {
  onBack: () => void;
}

export function Settings({ onBack }: SettingsProps) {
  const [businessInfo, setBusinessInfo] = useState({
    name: BUSINESS_INFO.name,
    phone: BUSINESS_INFO.phone,
    address: BUSINESS_INFO.address,
    hoursWeekday: BUSINESS_INFO.hours.weekday,
    hoursSaturday: BUSINESS_INFO.hours.saturday,
  });

  const [adminCredentials, setAdminCredentials] = useState({
    username: ADMIN_CREDENTIALS.username,
    password: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [saved, setSaved] = useState(false);

  const handleSaveBusiness = () => {
    // In a real app, this would save to backend
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleSaveCredentials = () => {
    if (adminCredentials.newPassword && adminCredentials.newPassword === adminCredentials.confirmPassword) {
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate-400" />
        </button>
        <h2 className="text-xl font-bold text-white">Configuración</h2>
      </div>

      {saved && (
        <div className="bg-green-500/20 border border-green-500/50 rounded-xl p-4 text-green-500 flex items-center gap-2">
          <Save className="w-5 h-5" />
          Cambios guardados correctamente
        </div>
      )}

      {/* Business Info */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Store className="w-5 h-5 text-amber-500" />
          Información del Negocio
        </h3>
        
        <div className="space-y-4">
          <div>
            <Label className="text-slate-300 flex items-center gap-2 mb-2">
              <Store className="w-4 h-4" /> Nombre del Negocio
            </Label>
            <Input
              value={businessInfo.name}
              onChange={(e) => setBusinessInfo({ ...businessInfo, name: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-slate-300 flex items-center gap-2 mb-2">
              <Phone className="w-4 h-4" /> Teléfono / WhatsApp
            </Label>
            <Input
              value={businessInfo.phone}
              onChange={(e) => setBusinessInfo({ ...businessInfo, phone: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-slate-300 flex items-center gap-2 mb-2">
              <MapPin className="w-4 h-4" /> Dirección
            </Label>
            <Input
              value={businessInfo.address}
              onChange={(e) => setBusinessInfo({ ...businessInfo, address: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4" /> Horario L-V
              </Label>
              <Input
                value={businessInfo.hoursWeekday}
                onChange={(e) => setBusinessInfo({ ...businessInfo, hoursWeekday: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-slate-300 flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4" /> Horario Sáb
              </Label>
              <Input
                value={businessInfo.hoursSaturday}
                onChange={(e) => setBusinessInfo({ ...businessInfo, hoursSaturday: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
          </div>

          <button
            onClick={handleSaveBusiness}
            className="w-full py-3 bg-amber-500 text-slate-900 rounded-xl font-medium hover:bg-amber-400 transition-colors flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            Guardar Cambios
          </button>
        </div>
      </div>

      {/* Admin Credentials */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <User className="w-5 h-5 text-amber-500" />
          Credenciales de Administrador
        </h3>
        
        <div className="space-y-4">
          <div>
            <Label className="text-slate-300 flex items-center gap-2 mb-2">
              <User className="w-4 h-4" /> Usuario
            </Label>
            <Input
              value={adminCredentials.username}
              onChange={(e) => setAdminCredentials({ ...adminCredentials, username: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-slate-300 flex items-center gap-2 mb-2">
              <Lock className="w-4 h-4" /> Contraseña Actual
            </Label>
            <Input
              type="password"
              value={adminCredentials.password}
              onChange={(e) => setAdminCredentials({ ...adminCredentials, password: e.target.value })}
              placeholder="••••••"
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-slate-300 flex items-center gap-2 mb-2">
              <Lock className="w-4 h-4" /> Nueva Contraseña
            </Label>
            <Input
              type="password"
              value={adminCredentials.newPassword}
              onChange={(e) => setAdminCredentials({ ...adminCredentials, newPassword: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-slate-300 flex items-center gap-2 mb-2">
              <Lock className="w-4 h-4" /> Confirmar Nueva Contraseña
            </Label>
            <Input
              type="password"
              value={adminCredentials.confirmPassword}
              onChange={(e) => setAdminCredentials({ ...adminCredentials, confirmPassword: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <button
            onClick={handleSaveCredentials}
            disabled={!adminCredentials.password || !adminCredentials.newPassword || adminCredentials.newPassword !== adminCredentials.confirmPassword}
            className="w-full py-3 bg-amber-500 text-slate-900 rounded-xl font-medium hover:bg-amber-400 transition-colors flex items-center justify-center gap-2 disabled:bg-slate-700 disabled:text-slate-500"
          >
            <Save className="w-4 h-4" />
            Cambiar Contraseña
          </button>
        </div>
      </div>
    </div>
  );
}
