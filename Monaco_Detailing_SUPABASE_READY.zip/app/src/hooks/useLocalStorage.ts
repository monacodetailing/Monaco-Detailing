import { useState, useEffect, useCallback } from 'react';
import type { Booking } from '@/types';

const BOOKINGS_KEY = 'monaco_bookings';

export function useLocalStorage() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(BOOKINGS_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setBookings(parsed);
      } catch (e) {
        console.error('Error parsing bookings:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings));
    }
  }, [bookings, isLoaded]);

  const addBooking = useCallback((booking: Omit<Booking, 'id' | 'createdAt' | 'status'>) => {
    const newBooking: Booking = {
      ...booking,
      id: `booking_${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'pending',
    };
    setBookings(prev => [...prev, newBooking]);
    return newBooking;
  }, []);

  const updateBookingStatus = useCallback((bookingId: string, status: Booking['status']) => {
    setBookings(prev =>
      prev.map(booking =>
        booking.id === bookingId ? { ...booking, status } : booking
      )
    );
  }, []);

  const deleteBooking = useCallback((bookingId: string) => {
    setBookings(prev => prev.filter(booking => booking.id !== bookingId));
  }, []);

  const getBookingById = useCallback((bookingId: string) => {
    return bookings.find(booking => booking.id === bookingId);
  }, [bookings]);

  const getBookingsByDate = useCallback((date: string) => {
    return bookings.filter(booking => booking.date === date);
  }, [bookings]);

  const getUpcomingBookings = useCallback(() => {
    const today = new Date().toISOString().split('T')[0];
    return bookings
      .filter(booking => booking.date >= today && booking.status !== 'cancelled')
      .sort((a, b) => {
        const dateCompare = a.date.localeCompare(b.date);
        if (dateCompare !== 0) return dateCompare;
        return a.time.localeCompare(b.time);
      });
  }, [bookings]);

  const getStats = useCallback(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const today = now.toISOString().split('T')[0];

    const monthlyBookings = bookings.filter(booking => {
      const bookingDate = new Date(booking.date);
      return (
        bookingDate.getMonth() === currentMonth &&
        bookingDate.getFullYear() === currentYear &&
        booking.status !== 'cancelled'
      );
    });

    const monthlyIncome = monthlyBookings.reduce((sum, booking) => sum + booking.total, 0);

    const todayBookings = bookings.filter(
      booking => booking.date === today && booking.status !== 'cancelled'
    ).length;

    return {
      monthlyIncome,
      monthlyBookings: monthlyBookings.length,
      todayBookings,
    };
  }, [bookings]);

  return {
    bookings,
    isLoaded,
    addBooking,
    updateBookingStatus,
    deleteBooking,
    getBookingById,
    getBookingsByDate,
    getUpcomingBookings,
    getStats,
  };
}
