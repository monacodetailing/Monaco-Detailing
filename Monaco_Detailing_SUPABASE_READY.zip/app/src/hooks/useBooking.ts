import { useState, useCallback } from 'react';
import type { BookingData, BookingStep, VehicleType } from '@/types';

const initialBookingData: BookingData = {
  vehicle: null,
  services: [],
  date: null,
  time: null,
  customer: {
    name: '',
    whatsapp: '',
    patent: '',
    brand: '',
    model: '',
  },
};

export function useBooking() {
  const [currentStep, setCurrentStep] = useState<BookingStep>('vehicle');
  const [bookingData, setBookingData] = useState<BookingData>(initialBookingData);

  const selectVehicle = useCallback((vehicle: VehicleType) => {
    setBookingData(prev => ({ 
      ...prev, 
      vehicle,
      services: [] // Reset services when vehicle changes
    }));
  }, []);

  const toggleService = useCallback((serviceId: string) => {
    setBookingData(prev => {
      const isSelected = prev.services.includes(serviceId);
      const newServices = isSelected
        ? prev.services.filter(id => id !== serviceId)
        : [...prev.services, serviceId];
      
      return {
        ...prev,
        services: newServices,
      };
    });
  }, []);

  const selectDate = useCallback((date: Date) => {
    setBookingData(prev => ({ ...prev, date }));
  }, []);

  const selectTime = useCallback((time: string) => {
    setBookingData(prev => ({ ...prev, time }));
  }, []);

  const updateCustomerData = useCallback((field: keyof BookingData['customer'], value: string) => {
    setBookingData(prev => ({
      ...prev,
      customer: { ...prev.customer, [field]: value },
    }));
  }, []);

  const nextStep = useCallback(() => {
    const steps: BookingStep[] = ['vehicle', 'services', 'date', 'data', 'confirm', 'success'];
    const currentIndex = steps.indexOf(currentStep);
    if (currentIndex < steps.length - 1) {
      setCurrentStep(steps[currentIndex + 1]);
    }
  }, [currentStep]);

  const prevStep = useCallback(() => {
    const steps: BookingStep[] = ['vehicle', 'services', 'date', 'data', 'confirm', 'success'];
    const currentIndex = steps.indexOf(currentStep);
    if (currentIndex > 0) {
      setCurrentStep(steps[currentIndex - 1]);
    }
  }, [currentStep]);

  const resetBooking = useCallback(() => {
    setBookingData(initialBookingData);
    setCurrentStep('vehicle');
  }, []);

  const canProceed = useCallback(() => {
    switch (currentStep) {
      case 'vehicle':
        return bookingData.vehicle !== null;
      case 'services':
        return bookingData.services.length > 0;
      case 'date':
        return bookingData.date !== null && bookingData.time !== null;
      case 'data':
        return (
          bookingData.customer.name.trim() !== '' &&
          bookingData.customer.whatsapp.trim() !== '' &&
          bookingData.customer.patent.trim() !== '' &&
          bookingData.customer.brand.trim() !== '' &&
          bookingData.customer.model.trim() !== ''
        );
      default:
        return true;
    }
  }, [currentStep, bookingData]);

  return {
    currentStep,
    bookingData,
    selectVehicle,
    toggleService,
    selectDate,
    selectTime,
    updateCustomerData,
    nextStep,
    prevStep,
    resetBooking,
    canProceed,
    setCurrentStep,
  };
}
