import { useState, useCallback } from 'react';
import { ADMIN_CREDENTIALS } from '@/data/constants';

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');

  const login = useCallback((user: string, password: string): boolean => {
    if (user === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      setIsAuthenticated(true);
      setUsername(user);
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setIsAuthenticated(false);
    setUsername('');
  }, []);

  return {
    isAuthenticated,
    username,
    login,
    logout,
  };
}
