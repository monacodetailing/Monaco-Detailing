import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://zcyrgovvhxzjaoscxpdt.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjeXJnb3Z2aHh6amFvc2N4cGR0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE2MjEyNTIsImV4cCI6MjA4NzE5NzI1Mn0.kmV0fh3E8XtRm3jO0XPLnfN3yijEJ01FfRbTc1QWgXE";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
