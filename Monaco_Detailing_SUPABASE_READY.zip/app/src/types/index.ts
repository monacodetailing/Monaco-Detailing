export type VehicleType = 'autos' | 'suv' | 'pickup';

export type Vehicle = {
  id: VehicleType;
  name: string;
  description: string;
  icon: string;
}

export type Service = {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: number;
  vehicleType: VehicleType;
}

export type BookingData = {
  vehicle: VehicleType | null;
  services: string[];
  date: Date | null;
  time: string | null;
  customer: {
    name: string;
    whatsapp: string;
    patent: string;
    brand: string;
    model: string;
  };
}

export type Booking = {
  id: string;
  vehicle: VehicleType;
  services: string[];
  date: string;
  time: string;
  customer: {
    name: string;
    whatsapp: string;
    patent: string;
    brand: string;
    model: string;
  };
  status: 'pending' | 'waiting_deposit' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  total: number;
  duration: number;
  createdAt: string;
}

export type BookingStep = 'vehicle' | 'services' | 'date' | 'data' | 'confirm' | 'success';

export interface AdminStats {
  monthlyIncome: number;
  monthlyBookings: number;
  todayBookings: number;
}
