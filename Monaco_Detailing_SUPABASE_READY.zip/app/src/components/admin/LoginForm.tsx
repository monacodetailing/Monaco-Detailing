import { useState } from 'react';
import { Lock, User, LogIn } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface LoginFormProps {
  onLogin: (username: string, password: string) => boolean;
}

export function LoginForm({ onLogin }: LoginFormProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!username || !password) {
      setError('Por favor completá todos los campos');
      return;
    }

    const success = onLogin(username, password);
    if (!success) {
      setError('Usuario o contraseña incorrectos');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-amber-500 rounded-xl flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl font-bold text-slate-900">M</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Monaco Detailing</h1>
          <p className="text-slate-400">Portal Administrativo</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-slate-300 uppercase text-xs tracking-wider">
                Usuario
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Ingresá tu usuario"
                  className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 pl-10 focus:border-amber-500 focus:ring-amber-500/20"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-slate-300 uppercase text-xs tracking-wider">
                Contraseña
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ingresá tu contraseña"
                  className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 pl-10 focus:border-amber-500 focus:ring-amber-500/20"
                />
              </div>
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center">{error}</div>
            )}

            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-amber-500 text-slate-900 font-medium hover:bg-amber-400 transition-colors flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              Iniciar Sesión
            </button>
          </div>
        </form>

        <p className="text-center text-slate-500 text-sm mt-6">
          © 2025 Monaco Detailing. Todos los derechos reservados.
        </p>
      </div>
    </div>
  );
}
