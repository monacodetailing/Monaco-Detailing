import { useState } from 'react';
import { ArrowLeft, User, Phone, Car, Hash, Calendar, Clock, Wrench, DollarSign, CheckCircle, XCircle, Play } from 'lucide-react';
import type { Booking } from '@/types';
import { VEHICLES, SERVICES, BUSINESS_INFO } from '@/data/constants';
import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

interface BookingDetailProps {
  booking: Booking;
  onBack: () => void;
  onUpdateStatus: (bookingId: string, status: Booking['status']) => void;
}

export function BookingDetail({ booking, onBack, onUpdateStatus }: BookingDetailProps) {
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  const vehicle = VEHICLES.find(v => v.id === booking.vehicle);
  const selectedServices = SERVICES.filter(s => booking.services.includes(s.id));

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins}min`;
    if (mins === 0) return `${hours}h`;
    return `${hours}h ${mins}min`;
  };

  const getStatusBadge = (status: Booking['status']) => {
    const styles = {
      pending: 'bg-yellow-500/20 text-yellow-500',
      waiting_deposit: 'bg-orange-500/20 text-orange-500',
      confirmed: 'bg-green-500/20 text-green-500',
      in_progress: 'bg-blue-500/20 text-blue-500',
      completed: 'bg-slate-500/20 text-slate-400',
      cancelled: 'bg-red-500/20 text-red-500',
    };
    
    const labels = {
      pending: 'Pendiente',
      waiting_deposit: 'Esperando Seña',
      confirmed: 'Confirmado',
      in_progress: 'En Curso',
      completed: 'Terminado',
      cancelled: 'Cancelado',
    };

    return (
      <span className={`px-3 py-1 rounded-full text-sm font-medium ${styles[status]}`}>
        {labels[status]}
      </span>
    );
  };

  const sendWhatsAppMessage = (type: 'deposit' | 'confirmation' | 'completion') => {
    const phone = booking.customer.whatsapp.replace(/\D/g, '');
    let message = '';

    switch (type) {
      case 'deposit':
        const depositAmount = Math.round(booking.total * 0.3);
        message = `Hola ${booking.customer.name}! 👋\n\nTe escribimos de "Monaco Detailing".\n\nRecibimos tu solicitud para el ${vehicle?.name} (Patente: ${booking.customer.patent}).\n\nPara confirmar la fecha del ${format(parseISO(booking.date), 'EEEE d MMMM', { locale: es })} a las ${booking.time}hs necesitamos una seña inicial.\n\n📋 Servicios solicitados:\n${selectedServices.map(s => `• ${s.name}`).join('\n')}\n\n💰 Total del trabajo: $${booking.total.toLocaleString()}\n💳 Seña a abonar (30%): $${depositAmount.toLocaleString()}\n\n📋 Datos para transferir:\n• Banco: Banco Galicia\n• Alias: alias.ejemplo\n• CBU: 0000003100003231582215\n• Titular: Monaco Detailing\n\nEnvianos el comprobante por acá y te confirmo el turno! ✅`;
        break;
      case 'confirmation':
        const remainingAmount = Math.round(booking.total * 0.7);
        message = `¡Turno Confirmado! ✅\n\nTu lugar para el ${vehicle?.name} ya está reservado.\n\n📅 Fecha: ${format(parseISO(booking.date), 'EEEE d MMMM', { locale: es })}\n🕐 Hora: ${booking.time}hs\n📍 Ubicación: ${BUSINESS_INFO.address}\n\n📋 Servicios confirmados:\n${selectedServices.map(s => `• ${s.name}`).join('\n')}\n\n💰 Saldo restante a abonar: $${remainingAmount.toLocaleString()}\n(Seña abonada: $${Math.round(booking.total * 0.3).toLocaleString()})\n\n⚠️ IMPORTANTE:\n• Traer el auto con la menor cantidad de cosas posible\n• Tolerancia de espera: 15 minutos\n• Si no podés venir, avisanos con 24hs de anticipación\n\n¡Nos vemos! 🚗✨`;
        break;
      case 'completion':
        const finalRemaining = Math.round(booking.total * 0.7);
        message = `¡Tu auto está listo! 🎉🚗\n\nEl trabajo sobre el ${vehicle?.name} (Patente: ${booking.customer.patent}) quedó terminado.\n\n📋 Servicios realizados:\n${selectedServices.map(s => `• ${s.name}`).join('\n')}\n\n💰 Saldo restante a abonar: $${finalRemaining.toLocaleString()}\n(Seña abonada: $${Math.round(booking.total * 0.3).toLocaleString()})\n\n✅ Podés pasar a retirarlo a: ${BUSINESS_INFO.address}\n\n🕐 Horario: Hasta las 19:00hs\n\n¡Gracias por confiar en Monaco Detailing! ✨`;
        break;
    }

    const url = `https://wa.me/549${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const renderActions = () => {
    switch (booking.status) {
      case 'pending':
        return (
          <div className="space-y-3">
            <button
              onClick={() => {
                onUpdateStatus(booking.id, 'waiting_deposit');
                sendWhatsAppMessage('deposit');
              }}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-white font-medium hover:from-amber-400 hover:to-orange-400 transition-colors flex items-center justify-center gap-2"
            >
              <DollarSign className="w-4 h-4" />
              Solicitar Seña (30%)
            </button>
            <button
              onClick={() => {
                onUpdateStatus(booking.id, 'confirmed');
                sendWhatsAppMessage('confirmation');
              }}
              className="w-full py-3 px-4 rounded-xl bg-green-500 text-white font-medium hover:bg-green-400 transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              Confirmar sin Seña
            </button>
            <button
              onClick={() => setShowCancelConfirm(true)}
              className="w-full py-3 px-4 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
            >
              <XCircle className="w-4 h-4" />
              Cancelar
            </button>
          </div>
        );

      case 'waiting_deposit':
        return (
          <div className="space-y-3">
            <div className="bg-amber-500/10 rounded-xl p-4 border border-amber-500/20">
              <p className="text-amber-500 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Esperando comprobante de seña del cliente
              </p>
            </div>
            <button
              onClick={() => {
                onUpdateStatus(booking.id, 'confirmed');
                sendWhatsAppMessage('confirmation');
              }}
              className="w-full py-3 px-4 rounded-xl bg-green-500 text-white font-medium hover:bg-green-400 transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              Seña Recibida - Confirmar
            </button>
            <button
              onClick={() => setShowCancelConfirm(true)}
              className="w-full py-3 px-4 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
            >
              <XCircle className="w-4 h-4" />
              Cancelar
            </button>
          </div>
        );

      case 'confirmed':
        return (
          <div className="space-y-3">
            <div className="bg-green-500/10 rounded-xl p-4 border border-green-500/20">
              <p className="text-green-500 text-sm flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Turno confirmado y listo
              </p>
            </div>
            <button
              onClick={() => onUpdateStatus(booking.id, 'in_progress')}
              className="w-full py-3 px-4 rounded-xl bg-blue-500 text-white font-medium hover:bg-blue-400 transition-colors flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              Iniciar Servicio
            </button>
            <button
              onClick={() => setShowCancelConfirm(true)}
              className="w-full py-3 px-4 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
            >
              <XCircle className="w-4 h-4" />
              Cancelar
            </button>
          </div>
        );

      case 'in_progress':
        return (
          <div className="space-y-3">
            <div className="bg-blue-500/10 rounded-xl p-4 border border-blue-500/20">
              <p className="text-blue-500 text-sm flex items-center gap-2">
                <Play className="w-4 h-4" />
                Servicio en progreso
              </p>
            </div>
            <button
              onClick={() => {
                onUpdateStatus(booking.id, 'completed');
                sendWhatsAppMessage('completion');
              }}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 text-white font-medium hover:from-green-400 hover:to-emerald-400 transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              Marcar como Terminado
            </button>
            <button
              onClick={() => setShowCancelConfirm(true)}
              className="w-full py-3 px-4 rounded-xl bg-slate-700 text-white font-medium hover:bg-slate-600 transition-colors flex items-center justify-center gap-2"
            >
              <XCircle className="w-4 h-4" />
              Cancelar
            </button>
          </div>
        );

      case 'completed':
        return (
          <div className="bg-slate-700/50 rounded-xl p-4 border border-slate-600">
            <p className="text-slate-400 text-sm flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              Turno completado
            </p>
          </div>
        );

      case 'cancelled':
        return (
          <div className="bg-red-500/10 rounded-xl p-4 border border-red-500/20">
            <p className="text-red-500 text-sm flex items-center gap-2">
              <XCircle className="w-4 h-4" />
              Turno cancelado
            </p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={onBack}
          className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-slate-400" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-white">Turno #{booking.id.slice(-6)}</h2>
          <p className="text-slate-400 text-sm">
            Creado el {format(parseISO(booking.createdAt), 'd MMM yyyy', { locale: es })}
          </p>
        </div>
        {getStatusBadge(booking.status)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column - Info */}
        <div className="space-y-4">
          {/* Customer Info */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <h3 className="text-sm font-medium text-amber-500 mb-3 flex items-center gap-2">
              <User className="w-4 h-4" />
              CLIENTE
            </h3>
            <div className="space-y-2">
              <p className="text-white font-medium text-lg">{booking.customer.name}</p>
              <p className="text-slate-400 flex items-center gap-2">
                <Phone className="w-4 h-4" />
                {booking.customer.whatsapp}
              </p>
              <p className="text-slate-400 flex items-center gap-2">
                <Hash className="w-4 h-4" />
                Patente: {booking.customer.patent}
              </p>
            </div>
          </div>

          {/* Vehicle Info */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <h3 className="text-sm font-medium text-amber-500 mb-3 flex items-center gap-2">
              <Car className="w-4 h-4" />
              VEHÍCULO
            </h3>
            <div className="flex items-center gap-3">
              <span className="text-3xl">{vehicle?.icon}</span>
              <div>
                <p className="text-white font-medium">{vehicle?.name}</p>
                <p className="text-slate-400 text-sm">
                  {booking.customer.brand} {booking.customer.model}
                </p>
              </div>
            </div>
          </div>

          {/* Date & Time */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <h3 className="text-sm font-medium text-amber-500 mb-3 flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              FECHA Y HORA
            </h3>
            <p className="text-white">
              {format(parseISO(booking.date), 'EEEE, d MMMM yyyy', { locale: es })}
            </p>
            <p className="text-slate-400 flex items-center gap-2 mt-1">
              <Clock className="w-4 h-4" />
              {booking.time} · Duración: {formatDuration(booking.duration)}
            </p>
          </div>
        </div>

        {/* Right Column - Services & Actions */}
        <div className="space-y-4">
          {/* Services */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <h3 className="text-sm font-medium text-amber-500 mb-3 flex items-center gap-2">
              <Wrench className="w-4 h-4" />
              SERVICIOS SOLICITADOS
            </h3>
            <div className="space-y-2">
              {selectedServices.map(service => (
                <div key={service.id} className="flex justify-between items-center py-2 border-b border-slate-700 last:border-0">
                  <div>
                    <p className="text-white">{service.name}</p>
                    <p className="text-slate-500 text-xs">{service.description}</p>
                  </div>
                  <span className="text-amber-500 font-medium">${service.price.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Total */}
          <div className="bg-gradient-to-r from-amber-500/20 to-amber-600/20 rounded-xl p-4 border border-amber-500/30">
            <div className="flex justify-between items-center">
              <span className="text-amber-500 font-medium">TOTAL</span>
              <span className="text-amber-500 font-bold text-2xl">${booking.total.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center mt-1">
              <span className="text-slate-400 text-sm">Duración</span>
              <span className="text-slate-400 text-sm">{formatDuration(booking.duration)}</span>
            </div>
          </div>

          {/* Actions */}
          {renderActions()}
        </div>
      </div>

      {/* Cancel Confirmation Modal */}
      {showCancelConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-2xl p-6 max-w-md w-full border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-2">¿Cancelar turno?</h3>
            <p className="text-slate-400 mb-6">
              Esta acción no se puede deshacer. El turno será marcado como cancelado.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowCancelConfirm(false)}
                className="flex-1 py-3 px-4 rounded-xl bg-slate-800 text-white font-medium hover:bg-slate-700 transition-colors"
              >
                Volver
              </button>
              <button
                onClick={() => {
                  onUpdateStatus(booking.id, 'cancelled');
                  setShowCancelConfirm(false);
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-red-500 text-white font-medium hover:bg-red-400 transition-colors"
              >
                Confirmar Cancelación
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
