import { LayoutDashboard, Plus, Calendar, Settings, LogOut } from 'lucide-react';

interface SidebarProps {
  currentView: 'dashboard' | 'new-booking' | 'calendar' | 'settings';
  onChangeView: (view: SidebarProps['currentView']) => void;
  onLogout: () => void;
  adminName: string;
}

export function Sidebar({ currentView, onChangeView, onLogout, adminName }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'new-booking', label: 'Nuevo Registro', icon: Plus },
    { id: 'calendar', label: 'Calendario', icon: Calendar },
    { id: 'settings', label: 'Configuración', icon: Settings },
  ] as const;

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 min-h-screen flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center">
            <span className="text-xl font-bold text-slate-900">M</span>
          </div>
          <div>
            <h1 className="text-white font-bold">Monaco</h1>
            <p className="text-slate-500 text-xs">Detailing</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;

            return (
              <li key={item.id}>
                <button
                  onClick={() => onChangeView(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    isActive
                      ? 'bg-amber-500 text-slate-900 font-medium'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.label}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User & Logout */}
      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 mb-4 px-4">
          <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center">
            <span className="text-sm font-bold text-slate-900">
              {adminName.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <p className="text-white text-sm font-medium">{adminName}</p>
            <p className="text-slate-500 text-xs">Admin</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Cerrar Sesión
        </button>
      </div>
    </aside>
  );
}
