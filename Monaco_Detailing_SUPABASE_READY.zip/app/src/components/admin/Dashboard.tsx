import { DollarSign, Calendar, Clock, ChevronRight } from 'lucide-react';
import type { Booking } from '@/types';
import { VEHICLES, SERVICES } from '@/data/constants';
import { format, parseISO, isToday, isTomorrow } from 'date-fns';
import { es } from 'date-fns/locale';

interface DashboardProps {
  stats: {
    monthlyIncome: number;
    monthlyBookings: number;
    todayBookings: number;
  };
  upcomingBookings: Booking[];
  onViewBooking: (bookingId: string) => void;
}

export function Dashboard({ stats, upcomingBookings, onViewBooking }: DashboardProps) {
  const getStatusBadge = (status: Booking['status']) => {
    const styles = {
      pending: 'bg-yellow-500/20 text-yellow-500',
      waiting_deposit: 'bg-orange-500/20 text-orange-500',
      confirmed: 'bg-green-500/20 text-green-500',
      in_progress: 'bg-blue-500/20 text-blue-500',
      completed: 'bg-slate-500/20 text-slate-400',
      cancelled: 'bg-red-500/20 text-red-500',
    };
    
    const labels = {
      pending: 'Pendiente',
      waiting_deposit: 'Esperando Seña',
      confirmed: 'Confirmado',
      in_progress: 'En Curso',
      completed: 'Terminado',
      cancelled: 'Cancelado',
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status]}`}>
        {labels[status]}
      </span>
    );
  };

  const getDateLabel = (dateStr: string) => {
    const date = parseISO(dateStr);
    if (isToday(date)) return 'HOY';
    if (isTomorrow(date)) return 'MAÑANA';
    return format(date, 'EEEE d MMMM', { locale: es }).toUpperCase();
  };

  // Group bookings by date
  const groupedBookings = upcomingBookings.reduce((acc, booking) => {
    const label = getDateLabel(booking.date);
    if (!acc[label]) acc[label] = [];
    acc[label].push(booking);
    return acc;
  }, {} as Record<string, Booking[]>);

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-emerald-500/20 to-emerald-600/10 rounded-xl p-5 border border-emerald-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-emerald-400 text-xs uppercase tracking-wider mb-1">Ingresos del Mes</p>
              <p className="text-2xl font-bold text-white">${stats.monthlyIncome.toLocaleString()}</p>
              <p className="text-emerald-500/60 text-xs mt-1">Solo turnos completados</p>
            </div>
            <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-emerald-500" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 rounded-xl p-5 border border-blue-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-400 text-xs uppercase tracking-wider mb-1">Turnos del Mes</p>
              <p className="text-2xl font-bold text-white">{stats.monthlyBookings}</p>
              <p className="text-blue-500/60 text-xs mt-1">Excluyendo cancelados</p>
            </div>
            <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
              <Calendar className="w-6 h-6 text-blue-500" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-amber-500/20 to-amber-600/10 rounded-xl p-5 border border-amber-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-400 text-xs uppercase tracking-wider mb-1">Turnos Hoy</p>
              <p className="text-2xl font-bold text-white">{stats.todayBookings}</p>
              <p className="text-amber-500/60 text-xs mt-1">Agenda hoy</p>
            </div>
            <div className="w-12 h-12 bg-amber-500/20 rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-amber-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Upcoming Bookings */}
      <div>
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-amber-500" />
          Próximos Turnos
        </h3>

        <div className="space-y-4">
          {Object.entries(groupedBookings).map(([dateLabel, bookings]) => (
            <div key={dateLabel}>
              <div className="flex items-center gap-3 mb-3">
                <span className="text-xs font-medium text-amber-500 bg-amber-500/10 px-3 py-1 rounded-full">
                  {dateLabel}
                </span>
                <div className="flex-1 h-px bg-slate-800" />
              </div>

              <div className="space-y-2">
                {bookings.map((booking) => {
                  const vehicle = VEHICLES.find(v => v.id === booking.vehicle);
                  const serviceNames = booking.services
                    .map(sId => SERVICES.find(s => s.id === sId)?.name)
                    .filter(Boolean)
                    .slice(0, 2);

                  return (
                    <button
                      key={booking.id}
                      onClick={() => onViewBooking(booking.id)}
                      className="w-full bg-slate-800/50 hover:bg-slate-800 rounded-xl p-4 border border-slate-700 transition-colors flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-4">
                        <div className="text-2xl">{vehicle?.icon}</div>
                        <div className="text-left">
                          <p className="text-white font-medium">{booking.customer.name}</p>
                          <p className="text-slate-400 text-sm">{vehicle?.name}</p>
                          <div className="flex gap-2 mt-1">
                            {serviceNames.map((name, i) => (
                              <span key={i} className="text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded">
                                {name}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-amber-500 font-semibold">{booking.time}</p>
                          <p className="text-slate-400 text-sm">${booking.total.toLocaleString()}</p>
                        </div>
                        {getStatusBadge(booking.status)}
                        <ChevronRight className="w-5 h-5 text-slate-600 group-hover:text-slate-400 transition-colors" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {upcomingBookings.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No hay turnos próximos</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
