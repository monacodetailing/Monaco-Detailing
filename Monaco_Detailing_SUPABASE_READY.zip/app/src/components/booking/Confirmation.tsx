import { CheckCircle, Car, Wrench, Calendar, User, Phone, Hash, Clock, Loader2 } from 'lucide-react';
import { VEHICLES, SERVICES } from '@/data/constants';
import type { BookingData } from '@/types';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface ConfirmationProps {
  bookingData: BookingData;
  onConfirm: () => void;
  onEdit: () => void;
  isSubmitting?: boolean;
}

export function Confirmation({ bookingData, onConfirm, onEdit, isSubmitting = false }: ConfirmationProps) {
  const vehicle = VEHICLES.find(v => v.id === bookingData.vehicle);
  const selectedServices = SERVICES.filter(s => bookingData.services.includes(s.id));
  
  const totalPrice = selectedServices.reduce((sum, s) => sum + s.price, 0);
  const totalDuration = selectedServices.reduce((sum, s) => sum + s.duration, 0);

  const formatTimeDisplay = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins} min`;
    if (mins === 0) return `${hours} h`;
    return `${hours}h ${mins}min`;
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white mb-1">
        5. Confirmá tu reserva
      </h3>
      <p className="text-slate-400 text-sm mb-4">Revisá que todo esté correcto</p>

      <div className="space-y-3">
        {/* Vehicle */}
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 text-amber-500 mb-2">
            <Car className="w-4 h-4" />
            <span className="text-xs font-medium uppercase tracking-wider">Vehículo</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-2xl">{vehicle?.icon}</span>
            <div>
              <div className="text-white font-medium">{vehicle?.name}</div>
              <div className="text-slate-400 text-sm">{vehicle?.description}</div>
            </div>
          </div>
        </div>

        {/* Services */}
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 text-amber-500 mb-2">
            <Wrench className="w-4 h-4" />
            <span className="text-xs font-medium uppercase tracking-wider">Servicios</span>
          </div>
          <div className="space-y-2">
            {selectedServices.map(service => (
              <div key={service.id} className="flex justify-between items-center">
                <span className="text-white text-sm">{service.name}</span>
                <span className="text-amber-500 text-sm">${service.price.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Date and Time */}
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 text-amber-500 mb-2">
            <Calendar className="w-4 h-4" />
            <span className="text-xs font-medium uppercase tracking-wider">Fecha y Hora</span>
          </div>
          <div className="text-white">
            {bookingData.date && format(bookingData.date, 'EEEE, d MMMM yyyy', { locale: es })}
          </div>
          <div className="flex items-center gap-2 text-slate-400 text-sm mt-1">
            <Clock className="w-3 h-3" />
            {bookingData.time} · Duración: {formatTimeDisplay(totalDuration)}
          </div>
        </div>

        {/* Customer Data */}
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 text-amber-500 mb-2">
            <User className="w-4 h-4" />
            <span className="text-xs font-medium uppercase tracking-wider">Tus Datos</span>
          </div>
          <div className="space-y-1 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Nombre:</span>
              <span className="text-white">{bookingData.customer.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-3 h-3 text-slate-400" />
              <span className="text-white">{bookingData.customer.whatsapp}</span>
            </div>
            <div className="flex items-center gap-2">
              <Car className="w-3 h-3 text-slate-400" />
              <span className="text-white">{bookingData.customer.brand} {bookingData.customer.model}</span>
            </div>
            <div className="flex items-center gap-2">
              <Hash className="w-3 h-3 text-slate-400" />
              <span className="text-white">{bookingData.customer.patent}</span>
            </div>
          </div>
        </div>

        {/* Total */}
        <div className="bg-gradient-to-r from-amber-500/20 to-amber-600/20 rounded-xl p-4 border border-amber-500/30">
          <div className="flex justify-between items-center">
            <span className="text-amber-500 font-medium">TOTAL A PAGAR</span>
            <span className="text-amber-500 font-bold text-2xl">${totalPrice.toLocaleString()}</span>
          </div>
          <p className="text-slate-400 text-xs mt-1">Se abona al finalizar el servicio</p>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-2">
        <button
          onClick={onEdit}
          disabled={isSubmitting}
          className="flex-1 py-3 px-4 rounded-xl bg-slate-800 text-white font-medium hover:bg-slate-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
        >
          ← Volver
        </button>
        <button
          onClick={onConfirm}
          disabled={isSubmitting}
          className="flex-1 py-3 px-4 rounded-xl bg-amber-500 text-slate-900 font-medium hover:bg-amber-400 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Guardando...
            </>
          ) : (
            <>
              <CheckCircle className="w-4 h-4" />
              Confirmar
            </>
          )}
        </button>
      </div>
    </div>
  );
}
