import type { VehicleType } from '@/types';
import { VEHICLES } from '@/data/constants';
import { Check } from 'lucide-react';

interface VehicleSelectionProps {
  selectedVehicle: VehicleType | null;
  onSelect: (vehicle: VehicleType) => void;
}

export function VehicleSelection({ selectedVehicle, onSelect }: VehicleSelectionProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white mb-2">
        1. Seleccioná tu vehículo
      </h3>
      <p className="text-slate-400 text-sm mb-4">Elegí el tipo que mejor se ajuste</p>
      
      <div className="grid grid-cols-2 gap-3">
        {VEHICLES.map((vehicle) => (
          <button
            key={vehicle.id}
            onClick={() => onSelect(vehicle.id)}
            className={`relative p-4 rounded-xl border-2 transition-all duration-200 text-left ${
              selectedVehicle === vehicle.id
                ? 'border-amber-500 bg-amber-500/10'
                : 'border-slate-700 bg-slate-800/50 hover:border-slate-600 hover:bg-slate-800'
            }`}
          >
            <div className="text-3xl mb-2">{vehicle.icon}</div>
            <div className="font-medium text-white">{vehicle.name}</div>
            <div className="text-xs text-slate-400">{vehicle.description}</div>
            
            {selectedVehicle === vehicle.id && (
              <div className="absolute top-2 right-2 w-5 h-5 bg-amber-500 rounded-full flex items-center justify-center">
                <Check className="w-3 h-3 text-slate-900" />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
