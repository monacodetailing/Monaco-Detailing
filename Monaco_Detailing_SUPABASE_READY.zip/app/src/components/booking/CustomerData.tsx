import { User, Phone, Car, Hash } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface CustomerDataProps {
  data: {
    name: string;
    whatsapp: string;
    patent: string;
    brand: string;
    model: string;
  };
  onUpdate: (field: keyof CustomerDataProps['data'], value: string) => void;
}

export function CustomerData({ data, onUpdate }: CustomerDataProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white mb-1">
        4. Tus datos
      </h3>
      <p className="text-slate-400 text-sm mb-4">Necesitamos tu info para confirmar la reserva</p>

      <div className="space-y-4">
        {/* Name */}
        <div className="space-y-2">
          <Label htmlFor="name" className="text-slate-300 flex items-center gap-2">
            <User className="w-4 h-4" />
            Nombre Completo <span className="text-amber-500">*</span>
          </Label>
          <Input
            id="name"
            value={data.name}
            onChange={(e) => onUpdate('name', e.target.value)}
            placeholder="Juan Perez"
            className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-amber-500 focus:ring-amber-500/20"
          />
        </div>

        {/* WhatsApp */}
        <div className="space-y-2">
          <Label htmlFor="whatsapp" className="text-slate-300 flex items-center gap-2">
            <Phone className="w-4 h-4" />
            WhatsApp <span className="text-amber-500">*</span>
          </Label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">
              +54 9
            </span>
            <Input
              id="whatsapp"
              value={data.whatsapp}
              onChange={(e) => onUpdate('whatsapp', e.target.value)}
              placeholder="351 123 4567"
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-amber-500 focus:ring-amber-500/20 pl-16"
            />
          </div>
        </div>

        {/* Vehicle Data Section */}
        <div className="pt-4 border-t border-slate-700">
          <h4 className="text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">
            Datos del Vehículo
          </h4>

          {/* Patent */}
          <div className="space-y-2 mb-4">
            <Label htmlFor="patent" className="text-slate-300 flex items-center gap-2">
              <Hash className="w-4 h-4" />
              Patente <span className="text-amber-500">*</span>
            </Label>
            <Input
              id="patent"
              value={data.patent}
              onChange={(e) => onUpdate('patent', e.target.value.toUpperCase())}
              placeholder="ABC123"
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-amber-500 focus:ring-amber-500/20 uppercase"
            />
          </div>

          {/* Brand and Model */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="brand" className="text-slate-300 flex items-center gap-2">
                <Car className="w-4 h-4" />
                Marca <span className="text-amber-500">*</span>
              </Label>
              <Input
                id="brand"
                value={data.brand}
                onChange={(e) => onUpdate('brand', e.target.value)}
                placeholder="Toyota"
                className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-amber-500 focus:ring-amber-500/20"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="model" className="text-slate-300 flex items-center gap-2">
                Modelo <span className="text-amber-500">*</span>
              </Label>
              <Input
                id="model"
                value={data.model}
                onChange={(e) => onUpdate('model', e.target.value)}
                placeholder="Corolla"
                className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500 focus:border-amber-500 focus:ring-amber-500/20"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
