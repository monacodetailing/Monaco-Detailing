import { CheckCircle, Calendar, Clock, Car, Wrench, MessageCircle, RotateCcw, Home } from 'lucide-react';
import { VEHICLES, SERVICES } from '@/data/constants';
import type { Booking } from '@/types';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface SuccessViewProps {
  booking: Booking;
  onNewBooking: () => void;
  onGoHome: () => void;
}

export function SuccessView({ booking, onNewBooking, onGoHome }: SuccessViewProps) {
  const vehicle = VEHICLES.find(v => v.id === booking.vehicle);
  const selectedServices = SERVICES.filter(s => booking.services.includes(s.id));
  
  const totalPrice = selectedServices.reduce((sum, s) => sum + s.price, 0);
  const totalDuration = selectedServices.reduce((sum, s) => sum + s.duration, 0);

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins}min`;
    if (mins === 0) return `${hours}h`;
    return `${hours}h ${mins}min`;
  };

  const handleWhatsAppContact = () => {
    const message = `Hola! Soy ${booking.customer.name}. Acabo de hacer una reserva para el ${format(new Date(booking.date), 'dd/MM/yyyy')} a las ${booking.time}. Quería consultar sobre los detalles.`;
    const url = `https://wa.me/5491130204512?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="text-center space-y-6">
      {/* Success Icon */}
      <div className="flex justify-center">
        <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center animate-bounce">
          <CheckCircle className="w-10 h-10 text-white" />
        </div>
      </div>

      <div>
        <h3 className="text-2xl font-bold text-white mb-2">
          ¡Reserva Confirmada!
        </h3>
        <p className="text-slate-400">
          Te contactaremos por WhatsApp para confirmar los detalles.
        </p>
      </div>

      {/* Summary Card */}
      <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700 text-left space-y-3">
        <div className="flex items-center gap-3">
          <Calendar className="w-4 h-4 text-amber-500" />
          <div>
            <div className="text-xs text-slate-500 uppercase">Fecha</div>
            <div className="text-white">
              {format(new Date(booking.date), 'EEE, d MMM', { locale: es })}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Clock className="w-4 h-4 text-amber-500" />
          <div>
            <div className="text-xs text-slate-500 uppercase">Hora</div>
            <div className="text-white">{booking.time}</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Car className="w-4 h-4 text-amber-500" />
          <div>
            <div className="text-xs text-slate-500 uppercase">Vehículo</div>
            <div className="text-white">{vehicle?.name}</div>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Wrench className="w-4 h-4 text-amber-500 mt-0.5" />
          <div>
            <div className="text-xs text-slate-500 uppercase">Servicios</div>
            <div className="text-white text-sm">
              {selectedServices.map(s => s.name).join(', ')}
            </div>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-700">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-sm">Total Estimado</span>
            <span className="text-amber-500 font-bold text-xl">${totalPrice.toLocaleString()}</span>
          </div>
          <div className="text-slate-500 text-xs text-right">
            Duración: {formatDuration(totalDuration)}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="space-y-3">
        <button
          onClick={handleWhatsAppContact}
          className="w-full py-3 px-4 rounded-xl bg-green-500 text-white font-medium hover:bg-green-400 transition-colors flex items-center justify-center gap-2"
        >
          <MessageCircle className="w-5 h-5" />
          Contactar por WhatsApp
        </button>
        
        <button
          onClick={onNewBooking}
          className="w-full py-3 px-4 rounded-xl bg-amber-500 text-slate-900 font-medium hover:bg-amber-400 transition-colors flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-4 h-4" />
          Hacer otra reserva
        </button>
        
        <button
          onClick={onGoHome}
          className="w-full py-3 px-4 rounded-xl bg-slate-800 text-white font-medium hover:bg-slate-700 transition-colors flex items-center justify-center gap-2"
        >
          <Home className="w-4 h-4" />
          Volver al inicio
        </button>
      </div>
    </div>
  );
}
