import { useState } from 'react';
import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { AVAILABLE_HOURS } from '@/data/constants';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, getDay } from 'date-fns';
import { es } from 'date-fns/locale';

interface DateSelectionProps {
  selectedDate: Date | null;
  selectedTime: string | null;
  onSelectDate: (date: Date) => void;
  onSelectTime: (time: string) => void;
}

export function DateSelection({ selectedDate, selectedTime, onSelectDate, onSelectTime }: DateSelectionProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const weekDays = ['DO', 'LU', 'MA', 'MI', 'JU', 'VI', 'SA'];

  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));

  const isToday = (date: Date) => {
    const today = new Date();
    return isSameDay(date, today);
  };

  const isSelected = (date: Date) => {
    return selectedDate ? isSameDay(date, selectedDate) : false;
  };

  const isPast = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white mb-1">
        3. Fecha y hora
      </h3>
      <p className="text-slate-400 text-sm mb-4">Elegí cuándo querés venir</p>

      {/* Calendar */}
      <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
        {/* Month Navigation */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={prevMonth}
            className="p-1 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-slate-400" />
          </button>
          <span className="text-white font-medium capitalize">
            {format(currentMonth, 'MMMM yyyy', { locale: es })}
          </span>
          <button
            onClick={nextMonth}
            className="p-1 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        {/* Week Days */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {weekDays.map((day) => (
            <div key={day} className="text-center text-xs text-slate-500 py-1">
              {day}
            </div>
          ))}
        </div>

        {/* Days */}
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: getDay(monthStart) }).map((_, i) => (
            <div key={`empty-${i}`} />
          ))}
          {days.map((day) => {
            const disabled = isPast(day);
            const selected = isSelected(day);
            const today = isToday(day);

            return (
              <button
                key={day.toISOString()}
                onClick={() => !disabled && onSelectDate(day)}
                disabled={disabled}
                className={`
                  aspect-square rounded-lg text-sm font-medium transition-all
                  ${disabled ? 'text-slate-600 cursor-not-allowed' : ''}
                  ${selected ? 'bg-amber-500 text-slate-900' : ''}
                  ${!selected && !disabled && today ? 'bg-slate-700 text-white' : ''}
                  ${!selected && !disabled && !today ? 'hover:bg-slate-700 text-slate-300' : ''}
                `}
              >
                {format(day, 'd')}
              </button>
            );
          })}
        </div>
      </div>

      {/* Time Selection */}
      {selectedDate && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-slate-400">
            <Clock className="w-4 h-4" />
            <span className="text-sm">Horarios Disponibles</span>
            <span className="text-xs bg-slate-800 px-2 py-0.5 rounded-full">
              {AVAILABLE_HOURS.length}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {AVAILABLE_HOURS.map((hour) => (
              <button
                key={hour}
                onClick={() => onSelectTime(hour)}
                className={`
                  py-2 px-3 rounded-lg text-sm font-medium transition-all
                  ${selectedTime === hour
                    ? 'bg-amber-500 text-slate-900'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                  }
                `}
              >
                {hour}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Selected Date/Time Summary */}
      {selectedDate && selectedTime && (
        <div className="bg-slate-800/50 rounded-xl p-3 border border-slate-700">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-sm">Fecha y Hora elegida</span>
          </div>
          <div className="text-white font-medium mt-1">
            {format(selectedDate, 'EEE, d MMM', { locale: es })} · {selectedTime}
          </div>
        </div>
      )}
    </div>
  );
}
